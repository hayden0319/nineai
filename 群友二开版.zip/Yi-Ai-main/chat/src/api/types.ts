export interface ResData {
  success: boolean
  message: string
  data: any
}
