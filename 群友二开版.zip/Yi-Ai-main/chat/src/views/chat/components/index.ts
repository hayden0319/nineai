import Message from './Message/index.vue'

export { Message }
