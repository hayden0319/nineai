export function getRandomItemFromArray<T>(array: T[]): T | null {
  if (array.length === 0) {
    return null;
  }
  const randomIndex = Math.floor(Math.random() * array.length);
  return array[randomIndex];
}
